// Problem:
// Given: a string input of 2 numbers separated by a space. i.e. "1 10"
// Solve: Find the highest occurring digit of the prime numbers that occur in the range given by the input (inclusive). 

// If multiple digits occur the same highest number of times return the greater. 

// Example 1: for the input "1 10" the highest occurring digit is 7
// Example 2: for the input "1 20" the highest occurring digit is 1


// Expectations:
// Please track your time to complete
// Your code should be in one file executable via the command "node index.js"
// You can choose how to pass the input to the program (command line, prompt etc...)
// Please do not use any external dependencies
// Please submit via github


//Osman Khan
//Florence coding assessment 
//Time total: 28 minutes and 12 seconds

var highestPrimeDigit = function(strs){
    //edge cases
    if (strs.length === 0) {
        console.log("Sorry, there is no valid input. The value returned is null");
        return null;
    }
    else if (strs.match(/[^0-9\s]/) !== null){
        console.log("Sorry, there are characters other than digits in then input. The value returned is null");
        return null;
    }
    strs = strs.split(' ');
    //another edge case
    if (strs.length > 2 || strs.length < 2){
        console.log("Sorry, invalid input. There must be 2 numbers seperated with a single space");
        return null;
    }
    const lowerRange = parseInt(strs[0]);
    const upperRange = parseInt(strs[1]);
    let countPrimeDigits = new Map();
    countPrimeDigits.set(1,0);
    countPrimeDigits.set(3,0);
    countPrimeDigits.set(5,0);
    countPrimeDigits.set(7,0);

    for (let i = lowerRange; i < upperRange; i++){
        const digits = i.toString().split('');
        for (let digit of digits){
            digit = parseInt(digit);
            if (countPrimeDigits.has(digit) === true){
                const currentValue = countPrimeDigits.get(digit);
                countPrimeDigits.set(digit,currentValue+1);
            }
        }
    }

    let highestOccuringCount = 0;
    let highestOccuringDigit = null;

    for (let [key,value] of countPrimeDigits){
        if (value > highestOccuringCount){
            highestOccuringCount = value;
            highestOccuringDigit = key;
        }
        else if (value === highestOccuringCount){
            if (key > highestOccuringDigit){
                highestOccuringDigit = key;
            }
        }

    }
    return highestOccuringDigit
};

console.log(highestPrimeDigit('1 10'));
console.log(highestPrimeDigit('1 20'));
console.log(highestPrimeDigit('')); //testing valid input
console.log(highestPrimeDigit('A 20')); //testing valid input
console.log(highestPrimeDigit('1 20 30')); //testing valid input
